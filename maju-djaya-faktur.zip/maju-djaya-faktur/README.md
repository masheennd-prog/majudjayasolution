# Faktur Penjualan - Maju Djaya Solution

Aplikasi web faktur/nota penjualan untuk **Maju Djaya Solution**
(Service Laptop/PC - Printer - CCTV - Jaringan - POS System).
Berjalan penuh di browser, tanpa server dan tanpa instalasi.

## Fitur
- Buat faktur: pelanggan, daftar barang, diskon, ongkos kirim, terbilang otomatis
- Riwayat penjualan: cari, ubah, hapus, cetak ulang, ekspor CSV, cadangkan/pulihkan JSON
- Pop up cetak dengan pratinjau: kertas Letter, struk 80mm, struk 58mm, salinan, skala, margin
- Login admin dengan username dan password yang bisa diubah
- Pengaturan identitas usaha (nama, layanan, alamat, WA, garansi)

## Struktur
```
index.html      halaman utama
css/style.css   tampilan (layar dan cetak)
js/app.js       seluruh logika aplikasi
```

## Menjalankan di komputer sendiri
Buka `index.html` dengan Chrome atau Edge. Tidak perlu server.

## Login bawaan
Username `admin`, password `admin123`. **Segera ganti** di Pengaturan > Akun admin.

## Penyimpanan data
Faktur, pengaturan, dan akun disimpan di `localStorage` browser, bukan di repositori ini.
Artinya data tidak ikut ke GitHub dan tiap browser/perangkat punya riwayat sendiri.
Gunakan tombol **Cadangkan (JSON)** di tab Riwayat secara rutin.

## Catatan keamanan
Login berjalan di sisi browser, jadi hanya penghalang ringan, bukan pengamanan sungguhan.
Kode sumber bisa dibaca siapa pun yang membuka situsnya. Jika situs di-hosting online,
kunci aksesnya di sisi server (mis. Cloudflare Access atau kata sandi Nginx/cPanel).

## Deploy ke GitHub Pages
1. Buka **Settings > Pages** pada repositori ini.
2. Di **Build and deployment**, pilih **Source: Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
3. Tunggu beberapa menit, situs tersedia di `https://USERNAME.github.io/NAMA-REPO/`.

Situs GitHub Pages bisa dibuka publik. Untuk akses pribadi, lihat opsi Cloudflare Pages di bawah.

## Deploy pribadi: GitHub + Cloudflare Pages
1. Di Cloudflare buka **Workers & Pages > Create > Pages > Connect to Git**, pilih repositori ini.
2. Biarkan *Build command* kosong dan *Output directory* `/`, lalu **Save and Deploy**.
3. Kunci dengan **Zero Trust > Access > Applications** (Self-hosted), aturan *Allow* untuk email Anda.
4. Setiap `git push` ke `main` otomatis memperbarui situs.
